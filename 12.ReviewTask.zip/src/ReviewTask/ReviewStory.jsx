import React from "react";
import "./ReviewStyling.css";

export default function ReviewStory({ imgURL, title, storyLine }) {
  //

  return (
    <div>
      <div>
        <h1 className="text-center"> {title}</h1>
      </div>
      <div
        className="d-flex  Reviewstory"
        style={{ marginRight: "5px", marginLeft: "5px" }}
      >
        <img src={imgURL} alt="" style={{ width: "300px" }} />
          <div className="storyline">
        <h5 className="mt-2 ms-4 Reviewstoretext">
          {storyLine}
          <h6 className="mt-5 text-secondary">
            Plese Give Title And Some Suggestions About The Story And Give
            Rating For Story
          </h6>
        </h5>

          </div>
      </div>
    </div>
  );
}
