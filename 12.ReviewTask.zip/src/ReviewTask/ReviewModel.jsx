import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Form from "react-bootstrap/Form";
import "./ReviewStyling.css";
const intialState = {
  title: "",
  description: "",
  rating: "",
};
export default function ReviewModel({
  setAllreviewdata,
  allreviewdata,
  storyId,
}) {
  const [reviewvalue, setReviewvalue] = useState({ intialState });
  const [colourchange, setColourchange] = useState("");

  const [show, setShow] = useState(false);

  const toogle = () => {
    setReviewvalue(intialState);
    setShow(!show);
  };

  // Store data in table funtion  
  const ReviewStorefun = (e) => {
    e.preventDefault;
    if (reviewvalue.title.length > 0 && reviewvalue.rating !== "") {
      setAllreviewdata([...allreviewdata, { ...reviewvalue, storyId }]);
      localStorage.setItem(
        "Storyreview",
        JSON.stringify([...allreviewdata, { ...reviewvalue, storyId }])
      );
      setReviewvalue(intialState);
      toogle();
    } else {
      alert("Please Give Your Review");
    }
  };

  // Reset All Data In form
  const ReviewResetfun = () => {
    setReviewvalue(intialState);

    document.querySelectorAll(".ratingstar > div").forEach((star) => {
      star.style.WebkitTextFillColor = "white";
    });
  };

  // Rating stars Colour Change Function
  const Ratingfun = (index) => {
    console.log("Ratingfun  index:", index);
    const color = "yellow";
    document.querySelectorAll(".ratingstar > div").forEach((star, i) => {
      if (i < index) star.style.WebkitTextFillColor = color;
      else star.style.WebkitTextFillColor = "white";
      setReviewvalue({ ...reviewvalue, rating: i });
      console.log("first", reviewvalue.rating);
    });
    setReviewvalue({ ...reviewvalue, rating: index });
  };

  
  return (
    <div style={{ marginLeft: "50px" }}>
      <Button className="me-5 ps-5 pe-5" variant="dark" onClick={toogle}>
        Give Review
      </Button>
      <Modal show={show} onHide={toogle}>
        <Modal.Header closeButton>
          <Modal.Title>Place Your Review Here</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Your Title"
                value={reviewvalue.title}
                required={true}
                onChange={(e) =>
                  setReviewvalue({
                    ...reviewvalue,
                    title: e?.target?.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>Description</Form.Label>
              <Form.Control
                placeholder="Enter Your Description"
                as="textarea"
                rows={3}
                required={true}
                value={reviewvalue.description}
                onChange={(e) =>
                  setReviewvalue({
                    ...reviewvalue,
                    description: e?.target?.value,
                  })
                }
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label for="Description" style={{ margin: 0 }}>
                Rating
              </Form.Label>
              <div className="ratingstar  d-flex">
                {[1, 2, 3, 4, 5].map?.((e, i) => {
                  return (
                    <Star
                      index={e}
                      Ratingfun={Ratingfun}
                      colourchange={colourchange}
                    />
                  );
                })}
              </div>
            </Form.Group>
            <Form.Group className="d-flex gap-4">
              <Button variant="dark" onClick={ReviewStorefun}>
                Submit
              </Button>
              <Button variant="dark" onClick={ReviewResetfun}>
                Reset
              </Button>
            </Form.Group>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}

const Star = ({ index, Ratingfun, colourchange }) => {
  return (
    <div
      className="star5"
      onClick={() => Ratingfun(index)}
      style={{
        color: "red",
        fontSize: "40px",
        cursor: "pointer",
        WebkitTextFillColor: colourchange,
      }}
    >
      &#9733;
    </div>
  );
};
