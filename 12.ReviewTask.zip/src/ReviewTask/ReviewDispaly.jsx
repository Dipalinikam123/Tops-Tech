import React, { useEffect, useState } from "react";
import ReviewStory from "./ReviewStory";
import ReviewModel from "./ReviewModel";
import ReviewTable from "./ReviewTable";
import "./ReviewStyling.css";
import data from "./data.json";
export default function ReviewDispaly() {
  const [allreviewdata, setAllreviewdata] = useState([]);

  // Get Data From Localstorege  To Table
  useEffect(() => {
    let normaldata = JSON.parse(localStorage.getItem("Storyreview") || "[]");
    setAllreviewdata(normaldata);
  }, []);

  // Delete function
  const ReviewDeletefun = (indexval) => {
    console.log("ReviewDeletefun  indexval:", indexval);
    if (confirm("Are You Sure For Delete This Review")) {
      const fillterdata = allreviewdata.filter((e, i) => i !== indexval);
      setAllreviewdata(fillterdata);
      localStorage.setItem("Storyreview", JSON.stringify(fillterdata));
    }
  };

  const dataStoryVise = (storyId) => {
    let data = [];
    allreviewdata.map((e, i) => {
      if (e.storyId === storyId) data.push({ ...e, index: i });
    });
    return data;
  };

  return (
    <div className="reviewmain">
      <div className="reviewdisplay ">
        {data.map((e, i) => {
          return (
            <>
              <h3
                style={{
                  textAlign: "center",
                  marginTop: "30px",
                  fontWeight: "900",
                  textDecoration: "underline",
                }}
              >
                STORY {i + 1}
              </h3>
              <div className="d-flex" key={{ i }}>
                <div className="reviewmodel">
                  <ReviewStory
                    imgURL={e.img}
                    title={e.title}
                    storyLine={e.storyLine}
                  />

                  <div className="w-100 d-flex justify-content-end">
                    <ReviewModel
                      allreviewdata={allreviewdata}
                      setAllreviewdata={setAllreviewdata}
                      storyId={e?.id}
                    />
                  </div>
                </div>
                <div className="reviwtable">
                  <ReviewTable
                    ReviewDeletefun={ReviewDeletefun}
                    allreviewdata={dataStoryVise(e?.id)}
                  />
                </div>
              </div>
              <hr style={{ marginTop: "50px", marginBottom: "20px" }} />
            </>
          );
        })}
      </div>
    </div>
  );
}
