import React from "react";
import "./ReviewStyling.css";
import Button from "react-bootstrap/Button";
export default function ReviewTable({ ReviewDeletefun, allreviewdata }) {
  return (
    <div>
      <div className=" mx-5">
        {allreviewdata.length > 0 && (
          <h1 className="text-center">Review Table</h1>
        )}
      </div>
      {allreviewdata.length > 0 ? (
        <div className="border ms-5 me-2 p-1 mt-3 showdata">
          {allreviewdata.map((e, i) => {
            return (
              <div
                key={i}
                className="border p-3 d-flex mb-1 justify-content-between "
              >
                <div>
                  <div>
                    <b>Title : </b>{" "}
                    <span style={{ color: "#8a8a8a" }}> {e.title}</span>
                  </div>

                  {e.description.length > 0 && (
                    <div>
                      <b>Description : </b>{" "}
                      <span style={{ color: "#8a8a8a" }}> {e.description}</span>
                    </div>
                  )}
                  {/* <div>
                    <b>Rating : </b> <span>{getStars(e.rating)} </span>
                  </div> */}
                  <div className="d-flex  gap-1 align-items-center">
                    <b>Rating : </b>{" "}
                    {Array.from({ length: e?.rating }, (_, index) => (
                      <span
                        key={index}
                        style={{ color: "yellow", fontSize: "25px" }}
                      >
                        &#9733;
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <Button
                    variant="danger"
                    onClick={() => ReviewDeletefun(e?.index)}
                  >
                    delete
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="emptytable text-center ">
          <h1> Review Not Available </h1>{" "}
        </div>
      )}
    </div>
  );
}
