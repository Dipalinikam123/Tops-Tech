
import './App.css'
import StoryShowPage from './Reviews/StoryShowPage'
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
 

  return (
    <>
    <StoryShowPage/>
    </>
  )
}

export default App
